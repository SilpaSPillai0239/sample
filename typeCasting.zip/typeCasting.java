package firstjava;

public class typeCasting {
	public static void main(String args[]) {
		
		System.out.println("Implementation of widening/implicit type casting");
		
		byte a=100;
		short b=a;
		int c=b;
		long d=c;
		float e=d;
		double f=e;
		System.out.println("value of a:" +a);
		System.out.println("value of b:" +b);
		System.out.println("value of c:" +c);
		System.out.println("value of d:" +d);
		System.out.println("value of e:" +e);
		System.out.println("value of f:" +f);
		
		System.out.println("Implementation of narrowing/explicit type casting");
		
		double x=45.5;
		int y=(int)x;
		byte z=(byte)y;
		System.out.println("value of double:" +x);
		System.out.println("value of integer:" +y);
		System.out.println("value of byte:" +z);}
}
