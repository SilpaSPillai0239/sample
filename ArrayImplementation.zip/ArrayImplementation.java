package firstjava;

public class ArrayImplementation {
	public static void main(String args[]) { 
		int arr1[]=new int[5];  
		arr1[0]=10;  
		arr1[1]=20;  
		arr1[2]=70;  
		arr1[3]=40;  
		arr1[4]=50;  
		System.out.println("Implementation of onedimensional array");
		for(int i=0;i<arr1.length;i++) {
			
		System.out.println(arr1[i]);  
}
		
		System.out.println("\n");
		System.out.println("Implementation of multidimensioanl array");
		int arr[][]={{1,2,3},{4,5,6},{7,8,9}};  
	  
		for(int i=0;i<3;i++){  
		 for(int j=0;j<3;j++){  
		   System.out.print(arr[i][j]+" ");  
		 }  
		 System.out.println();  
		}  
}
}
