package project2;

public class ThrowDemo {
	static void checkAge(int age) {
	    if (age < 18) {
	      throw new ArithmeticException("OOPS!!!! You are not eligible to caste vote, atleast need 18.");
	    }
	    else {
	      System.out.println("Permission sanctioned, eligible to caste vote.");
	    }
	  }

	  public static void main(String[] args) {
	    checkAge(20); 
	  }

}
