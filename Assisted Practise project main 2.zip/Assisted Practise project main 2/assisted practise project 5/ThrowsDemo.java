package project2;
import java.io.*;
public class ThrowsDemo {

	public static void problemFile() throws IOException {
	   
	    File newFile=new File("sample.txt");
	    FileInputStream stream=new FileInputStream(newFile);
	  }

	  public static void main(String[] args) {
	    try{
	    	 problemFile();
	    } catch(IOException e){
	      System.out.println(e);
	    }
	  }
}
