package project2;

class DivisionByZero extends Exception {
	  public DivisionByZero (String message) {
	    super(message);
	  }
	}
public class CustomException {
	public static void main(String[] args) {
		    try {
		      int result = divide(10, 0);
		      System.out.println(result);
		    } catch (DivisionByZero  e) {
		      System.out.println(e.getMessage());
		    }
		  }

		  public static int divide(int dividend, int divisor) throws DivisionByZero  {
		    if (divisor == 0) {
		      throw new DivisionByZero ("Cannot divide by zero");
		    }
		    return dividend / divisor;
		  }
		}

		


