package project2;

import java.util.*;
class employee
	{
	int eid,sal;
	String add,name;
	
	employee(int id,String n,String a,int s)
	{
	eid=id;
	 name=n;
	add=a;
	 sal=s;
	} 
	
	void display()
	{
	System.out.print("\nEMPLOYEE ID:"+eid+" \n");
	System.out.print("NAME:"+name+"\n");
	System.out.print("ADDRESS:"+add+"\n");
	System.out.print("SALARY:"+sal+"\n");
	}
}
class Teacher extends employee
{
	String sub,dep;
	Teacher(int id,String n,String a,int s,String de,String su)
	{
	super(id,n,a,s);
	 dep=de;
	sub=su;
	}
	void disp()
	{
	System.out.print("DEPARTMENT:"+dep+"\n");
	System.out.print("SUBJECTS:"+sub+"\n");
	}
}

public class Inheritance
	{
	public static void main(String[]args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.print("\nEnter the number of employees:");
	int l=sc.nextInt();

	Teacher emp[]=new Teacher[l];

	for(int i=0;i<l;i++)
	{
	
	System.out.print("\n***DETAILS OF EMPLOYEE"+(i+1)+"***\n");
	System.out.print("\nEnter employee id:");
	int id=sc.nextInt();
	System.out.print("Enter employee name:");
	sc.nextLine();
	String n=sc.nextLine();
	System.out.print("Enter employee address:");
	String a=sc.nextLine();
	System.out.print("Enter employee salary:");
	int s=sc.nextInt();
	System.out.print("Enter employee department:");
	sc.nextLine();
	String de=sc.nextLine();
	System.out.print("Enter the subjects taught:");
	String su=sc.nextLine();
	emp[i]=new Teacher(id,n,a,s,de,su);
	}
	for(int i=0;i<l;i++)
	{
	System.out.print("\n***EMPLOYEE "+(i+1)+"***\n");
	emp[i].display();
	emp[i].disp();
	}
     }
}
