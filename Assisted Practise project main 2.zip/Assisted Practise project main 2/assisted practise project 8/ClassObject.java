package project2;

public class ClassObject {
	public void display() {
	    System.out.println("This is going to implement the usage of class and objects in java");
	  }

	 
	  public void speed(int Speed) {
	    System.out.println("Max speed is: " +Speed);
	  }

	 
	  public static void main(String[] args) {
		  ClassObject race = new ClassObject();   
	    race.display();     
	    race.speed(150);         
	  }

}
