package project2;

class Geometry {
	  public void area() {
	    System.out.println("Here shows the formula for finding area of different shapes");
	  }
	}
	class Triangle extends Geometry {
	  public void area() {
	    System.out.println("Formula to find area of Triangle is � * base * height ");
	    
	    
	  }
	}
	class Circle extends Geometry{
	  public void area() {
	    System.out.println("Formula to find area of Circle is 3.14 * radius * radius ");
	  }
	}
	class Square extends Geometry{
		  public void area() {
		    System.out.println("Formula to find area of Square is side*side ");
		  }
		}
public class Polymorphism {
	public static void main(String[] args) {
		Geometry g=new Geometry();
		Geometry tria=new Triangle();
		Geometry cir=new Circle();
		Geometry squa=new Square();
		g.area();
		tria.area();
		cir.area();
		squa.area();
		
		
	}

}
