package project2;


class Bike {
    
    private int speed;
    private String color;     

   
    public int bikeSpeed() {
          return speed;
    }

    public void setSpeed(int speed) {
          this.speed = speed;
    }

    public String bikeColor() {
          return color;
    }

    public void setColor(String color) {
          this.color = color;
    }    
}


public class Encapsulation {
	public static void main(String args[]){
        
		Bike b = new Bike();          

        
       b.setColor("Black");
        b.setSpeed(120);           

        
        System.out.println("Bike color: " + b.bikeColor());
        System.out.println("Bike speed: " + b.bikeSpeed());
  }
}
