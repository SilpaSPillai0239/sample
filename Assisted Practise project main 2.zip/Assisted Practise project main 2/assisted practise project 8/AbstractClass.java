package project2;


abstract class calculation{
	 
	  public abstract void area();
	 
	  public void show() {
	    System.out.println("Here shows implementation of abstract class");
	  }
	}

	
	class calc extends calculation {
	  public void area() {
	   int rad= 10;
	   
	    System.out.println("Area of circle is:"+ (3.14*rad*rad));
	  }
	}
public class AbstractClass {
	public static void main(String[] args) {
	    calc mycalc = new calc(); // Create a Pig object
	    mycalc.area();
	    mycalc.show();
	  }
}
