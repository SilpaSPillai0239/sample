package project2;
import java.io.File; 

public class DeleteFile {
	
	
	public static void main(String[] args) { 
	    File info = new File("C:\\Users\\HP\\eclipse-workspace\\project2\\newfile.txt"); 
	    if (info.delete()) { 
	      System.out.println("Successfully deleted"+" "+ info.getName());
	    } else {
	      System.out.println("Some error occurs");
	    } 
	  } 

}
