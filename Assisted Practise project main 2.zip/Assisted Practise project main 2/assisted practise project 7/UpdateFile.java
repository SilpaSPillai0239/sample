package project2;
import java.io.*;
public class UpdateFile {
	
	
	public static void main(String[] args) {
        File info = new File("newfile.txt");

        try {
            
            FileWriter writer = new FileWriter(info , true);

            
            writer.write("\n Iam adding some more data into the existing file");

            
            writer.close();

            
            System.out.println("File updated successfully!");
        } catch (IOException e) {
           
            System.out.println("An error occurred: " + e.getMessage());
        }

}
}
