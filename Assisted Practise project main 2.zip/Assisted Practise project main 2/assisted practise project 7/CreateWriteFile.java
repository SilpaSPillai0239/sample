package project2;

import java.io.File;
import java.io.FileWriter; 
import java.io.IOException;
public class CreateWriteFile {
	
	public static void main(String[] args) {
		File myObj = new File("newfile.txt");
	
	    try {
	    	FileWriter myWriter = new FileWriter("newfile.txt");
	        myWriter.write("A B C D E F G H I J K L M N O P Q R S T U V W X Y Z...Here is the order of english alphabets");
	        myWriter.close();
	        System.out.println("Successfully wrote to the file.");
	      } catch (IOException e) {
	        System.out.println("An error occurred.");
	        e.printStackTrace();
	      }
	    }
	  }
	      

