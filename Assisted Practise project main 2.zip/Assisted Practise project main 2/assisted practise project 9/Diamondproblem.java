package project2;

interface root {
    void print();
}

class A implements root {
    public void print() {
        System.out.println("Amsterdam");
    }
}

class B implements root {
    public void print() {
        System.out.println("Berlin");
    }
}

class C implements root {
    public void print() {
        System.out.println("Canada");
    }
}

class D extends A implements root {
	root baseObj;

    public D(root baseObj) {
        this.baseObj = baseObj;
    }

    public void print() {
        super.print();
        baseObj.print();
    }
}
public class Diamondproblem {
	 public static void main(String[] args) {
	        D dObj = new D(new C());
	        
	        dObj.print();
	       
	    }
}
