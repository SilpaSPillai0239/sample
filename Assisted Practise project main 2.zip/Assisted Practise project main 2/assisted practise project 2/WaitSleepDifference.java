package project2;

public class WaitSleepDifference {
	private static Object time = new Object();
	 
	public static void main(String[] args)
	  throws InterruptedException {
	  
	    Thread.sleep(3000);
	   
	    System.out.println("Thread '" + Thread.currentThread().getName() +
	      "' is active after sleeping for 3 seconds");
	  
	    synchronized (time)
	    {
	    	time.wait(2000);
	       
	        System.out.println("Object '" + time + "' is active after" +
	          " waiting for 1 second");
	    }
	}
}
