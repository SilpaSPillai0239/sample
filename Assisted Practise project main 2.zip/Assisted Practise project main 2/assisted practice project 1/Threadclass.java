package project2;


public class Threadclass extends Thread{
	public void run() 
	{
		System.out.println("This is an example for Thread class extension");
	}
	public static void main(String[] args) {
		
		Threadclass tc=new Threadclass();
		tc.start();
	}

}
