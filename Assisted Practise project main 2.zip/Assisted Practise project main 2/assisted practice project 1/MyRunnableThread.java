package project2;
import java.util.*;
public class MyRunnableThread implements Runnable {
	public void run(){

		int n1=0,n2=1,n3=0;
		
			Scanner sc=new Scanner(System.in);
			
			System.out.print("enter the limit for fibonacci:");
			
			int n=sc.nextInt();
			System.out.println("fibonacci numbers from 0 to "+n+"are:\n");
			System.out.print(n1+" "+n2);
			for(int i=2;i<=n;i++){
				
				n3=n1+n2;
				System.out.print(" "+n3);
				n1=n2;
				n2=n3;
		}
			}
	public static void main(String[]args){
		MyRunnableThread rt=new MyRunnableThread();
		Thread t1=new Thread(rt);
		t1.start();
		
	}
	}
	

