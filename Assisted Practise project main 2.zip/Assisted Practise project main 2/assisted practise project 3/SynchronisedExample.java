package project2;

class synchronisation{  
		 synchronized void result(int n){
		   for(int i=1;i<=8;i++){  
		     System.out.println(n*i);  
		     try{  
		      Thread.sleep(100);  
		     }catch(Exception et){System.out.println(et);}  
		   }  
		  
		 }  
		}  
		  
		class MyThread1 extends Thread{  
			synchronisation t;  
		MyThread1(synchronisation t){  
		this.t=t;  
		}  
		public void run(){  
		t.result(5);  
		}  
		  
		}  
		class MyThread2 extends Thread{  
			synchronisation t;  
		MyThread2(synchronisation t){  
		this.t=t;  
		}  
		public void run(){  
		t.result(10);  
		}  
		}  
		  
		public class SynchronisedExample { 
		public static void main(String args[]){  
			synchronisation sync = new synchronisation();//only one object  
		MyThread1 t1=new MyThread1(sync);  
		MyThread2 t2=new MyThread2(sync);  
		t1.start();  
		t2.start();  
		}  
		} 
	



