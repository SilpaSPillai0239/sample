package project2;

class funds extends Exception {
    private double amount;

    public funds(double amount) {
        this.amount = amount;
    }

    public double getAmount() {
        return amount;
    }
}

class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public void withdraw(double amount) throws funds {
        if (amount > balance) {
            throw new funds(amount);
        }

        balance -= amount;
    }

    public double getBalance() {
        return balance;
    }
}

public class ExceptionHandling {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000.0);

        try {
           
            account.withdraw(1500.0);
        } catch (funds e) {
            
            System.out.println("Error: Insufficient funds. Required: " + e.getAmount() + ", Available: " + account.getBalance());
        }

        
        
    }
}



