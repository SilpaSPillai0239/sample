package project2;

public class TryCatchFinally {
	
		   public static void main(String args[]){
		    try{
		       int d = 0;
		       int n =10;
		       int result = n/d;
		    }
		  catch(ArithmeticException e){
		    System.out.println("Not divisible by zero exception arises "+e);
		  }
		  finally{
			System.out.println("Example of finally block");
		  }
		}
		}

